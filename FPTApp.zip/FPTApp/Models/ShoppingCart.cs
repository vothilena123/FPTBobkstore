﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FPTApp.Models
{
    public class ShoppingCart
    {
        public Guid BookID { get; set; }
        public decimal Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal Total { get; set; }

        public string ImagePath { get; set; }
        public string BookName { get; set; }
    }
}